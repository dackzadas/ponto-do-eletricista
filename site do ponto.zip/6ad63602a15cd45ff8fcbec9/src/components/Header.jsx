import { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { whatsappLink } from "@/config/site";
import { logoImage } from "@/data/products";

// Âncoras de navegação usadas no desktop e no menu mobile.
const NAV_LINKS = [
  { label: "Início", href: "#inicio" },
  { label: "Produtos", href: "#produtos" },
  { label: "Ofertas", href: "#ofertas" },
  { label: "Sobre", href: "#sobre" },
  { label: "Contato", href: "#contato" },
];

// Cabeçalho fixo: translúcido no topo e "glass" após rolar a página.
export default function Header() {
  const reduce = useReducedMotion();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <motion.header
      initial={reduce ? { opacity: 0 } : { opacity: 0, y: -24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        scrolled
          ? "glass border-b border-white/10"
          : "border-b border-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3.5 sm:px-8">
        <a
          href="#inicio"
          aria-label="Ponto do Eletricista — início"
          className="flex items-center gap-3 transition-transform hover:scale-105"
        >
          <img
            src={logoImage}
            alt=""
            className="h-10 w-10 object-contain sm:h-12 sm:w-12"
          />
          <div className="font-heading text-sm font-extrabold leading-[1.05] tracking-tight text-white sm:text-base">
            <span className="block">PONTO DO</span>
            <span className="block text-[#FFD400] text-glow">ELETRICISTA</span>
          </div>
        </a>

        {/* Navegação desktop */}
        <nav
          className="hidden items-center gap-8 md:flex"
          aria-label="Navegação principal"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-slate-300 transition hover:text-[#FFD400]"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* CTA desktop */}
        <a
          href={whatsappLink(
            "Olá! Gostaria de pedir um orçamento no Ponto do Eletricista."
          )}
          target="_blank"
          rel="noopener noreferrer"
          className="hidden rounded-full bg-[#FFD400] px-5 py-2.5 text-sm font-bold text-[#080B12] transition hover:shadow-[0_0_24px_rgba(255,212,0,0.5)] hover:brightness-105 md:inline-block"
        >
          Pedir orçamento
        </a>

        {/* Botão hambúrguer (mobile) */}
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Fechar menu" : "Abrir menu"}
          aria-expanded={open}
          className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 text-white transition hover:border-[#FFD400]/50 hover:text-[#FFD400] md:hidden"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Painel do menu mobile */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={reduce ? { opacity: 0 } : { opacity: 0, height: 0 }}
            animate={reduce ? { opacity: 1 } : { opacity: 1, height: "auto" }}
            exit={reduce ? { opacity: 0 } : { opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="glass overflow-hidden border-t border-white/10 md:hidden"
          >
            <nav
              className="mx-auto flex max-w-7xl flex-col gap-1 px-5 py-4 sm:px-8"
              aria-label="Navegação mobile"
            >
              {NAV_LINKS.map((link, i) => (
                <motion.a
                  key={link.href}
                  href={link.href}
                  onClick={() => setOpen(false)}
                  initial={reduce ? { opacity: 0 } : { opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 + i * 0.05, duration: 0.3 }}
                  className="rounded-xl px-4 py-3 text-sm font-medium text-slate-200 transition hover:bg-white/5 hover:text-[#FFD400]"
                >
                  {link.label}
                </motion.a>
              ))}
              <a
                href={whatsappLink(
                  "Olá! Gostaria de pedir um orçamento no Ponto do Eletricista."
                )}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setOpen(false)}
                className="mt-2 rounded-full bg-[#FFD400] px-5 py-3 text-center text-sm font-bold text-[#080B12] transition hover:brightness-105"
              >
                Pedir orçamento
              </a>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
