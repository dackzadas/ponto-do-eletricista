import { motion, useReducedMotion } from "framer-motion";
import { Check, MessageCircle, MapPin } from "lucide-react";
import { storeImage } from "@/data/products";
import { siteConfig, whatsappLink } from "@/config/site";
import { Image } from "@/components/ui/image";
import Reveal from "./Reveal";

// Motivos de confiança — afirmações genéricas, sem dados verificáveis.
const BULLETS = [
  "Atendimento a eletricistas, obras e reformas",
  "Variedade de materiais elétricos em um só lugar",
  "Suporte para encontrar o produto certo para o seu projeto",
];

export default function About() {
  const reduce = useReducedMotion();

  return (
    <section id="sobre" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          {/* Fotografia real da fachada da loja no Coroado */}
          <Reveal>
            <motion.div
              whileHover={reduce ? undefined : { scale: 1.02 }}
              transition={{ type: "spring", stiffness: 260, damping: 24 }}
              className="relative aspect-[4/3] overflow-hidden rounded-2xl card-glass"
            >
              <Image
                src={storeImage}
                alt="Fachada da loja Ponto do Eletricista no Coroado, Manaus"
                className="h-full w-full object-cover"
              />
              {/* Tags sobre a imagem (canto inferior esquerdo) */}
              <div className="absolute bottom-4 left-4 right-4 flex flex-wrap gap-2 sm:bottom-6 sm:left-6">
                <div className="flex items-center gap-2 rounded-full glass px-4 py-2 text-[10px] font-bold text-white shadow-lg backdrop-blur-md sm:text-xs">
                  <MapPin className="h-3 w-3 text-[#FFD400] sm:h-3.5 sm:w-3.5" />
                  {siteConfig.location}
                </div>
                <div className="flex items-center gap-2 rounded-full glass px-4 py-2 text-[10px] font-bold text-white shadow-lg backdrop-blur-md sm:text-xs">
                  <MessageCircle className="h-3 w-3 text-[#FFD400] sm:h-3.5 sm:w-3.5" />
                  {siteConfig.whatsappDisplay}
                </div>
              </div>
            </motion.div>
          </Reveal>

          {/* Texto sobre a loja */}
          <Reveal delay={0.1}>
            <span className="text-xs font-semibold uppercase tracking-[0.25em] text-[#FFD400]">
              Sobre
            </span>
            <h2 className="mt-4 font-heading text-3xl font-extrabold leading-tight text-white sm:text-4xl md:text-5xl">
              Materiais elétricos no{" "}
              <span className="text-[#FFD400] text-glow">Coroado, Manaus</span>
            </h2>
            <p className="mt-5 text-base leading-relaxed text-slate-400">
              O Ponto do Eletricista é a sua loja de materiais elétricos no bairro
              Coroado, em Manaus. Atendemos eletricistas, obras e reformas com
              cabos, disjuntores, tomadas, iluminação, ferramentas e muito mais.
              Conte com a nossa equipe para encontrar o material certo para o seu
              projeto.
            </p>

            <ul className="mt-6 space-y-3">
              {BULLETS.map((item, i) => (
                <Reveal as="li" key={item} delay={0.15 + i * 0.08}>
                  <span className="flex items-start gap-3">
                    <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[#FFD400]/10 text-[#FFD400] ring-1 ring-[#FFD400]/20">
                      <Check className="h-3.5 w-3.5" />
                    </span>
                    <span className="text-sm text-slate-300">{item}</span>
                  </span>
                </Reveal>
              ))}
            </ul>

            <motion.a
              href={whatsappLink(
                "Olá! Gostaria de conhecer os produtos do Ponto do Eletricista."
              )}
              target="_blank"
              rel="noopener noreferrer"
              whileHover={reduce ? undefined : { y: -2 }}
              whileTap={reduce ? undefined : { scale: 0.98 }}
              className="mt-8 inline-flex items-center justify-center gap-2 rounded-full bg-[#FFD400] px-6 py-3.5 font-bold text-[#080B12] transition hover:shadow-[0_0_24px_rgba(255,212,0,0.5)] hover:brightness-105"
            >
              <MessageCircle className="h-5 w-5" />
              Falar no WhatsApp
            </motion.a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
