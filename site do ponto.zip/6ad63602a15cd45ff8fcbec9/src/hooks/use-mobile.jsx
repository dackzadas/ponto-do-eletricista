import { useEffect, useState } from "react";

// Breakpoint de mobile: abaixo de 768px (combina com md: do Tailwind).
const MOBILE_QUERY = "(max-width: 767px)";

export function useIsMobile() {
  const [isMobile, setIsMobile] = useState(() => {
    if (typeof window === "undefined" || !window.matchMedia) return false;
    return window.matchMedia(MOBILE_QUERY).matches;
  });

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;

    const mql = window.matchMedia(MOBILE_QUERY);

    const onChange = (event) => {
      // Só atualiza o estado quando o valor realmente muda.
      setIsMobile((prev) => (prev === event.matches ? prev : event.matches));
    };

    // Sincroniza caso a viewport mude entre o render e o efeito.
    onChange(mql);
    mql.addEventListener("change", onChange);
    return () => mql.removeEventListener("change", onChange);
  }, []);

  return isMobile;
}
