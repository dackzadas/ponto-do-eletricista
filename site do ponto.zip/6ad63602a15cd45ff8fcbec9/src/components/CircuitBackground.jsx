import { motion, useReducedMotion } from "framer-motion";

// Trilhas de "circuito elétrico" decorativas ao fundo do Hero.
// SVG discreto em tons de amarelo #FFD400, com um pulso suave de opacidade.
export default function CircuitBackground() {
  const reduce = useReducedMotion();

  return (
    <div
      className="pointer-events-none absolute inset-0 overflow-hidden"
      aria-hidden="true"
    >
      <svg
        className="absolute inset-0 h-full w-full text-[#FFD400]"
        viewBox="0 0 1200 800"
        preserveAspectRatio="xMidYMid slice"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Malha base do circuito */}
          <pattern
            id="circuit-grid"
            width="80"
            height="80"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M80 0H0V80"
              stroke="currentColor"
              strokeWidth="1"
              strokeOpacity="0.18"
            />
          </pattern>
          {/* Desvanecimento para as bordas */}
          <radialGradient id="circuit-fade" cx="50%" cy="38%" r="65%">
            <stop offset="0%" stopColor="#fff" stopOpacity="1" />
            <stop offset="100%" stopColor="#fff" stopOpacity="0" />
          </radialGradient>
          <mask id="circuit-mask">
            <rect width="1200" height="800" fill="url(#circuit-fade)" />
          </mask>
        </defs>

        <motion.g
          mask="url(#circuit-mask)"
          initial={{ opacity: 0.5 }}
          animate={reduce ? undefined : { opacity: [0.4, 0.65, 0.4] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        >
          <rect width="1200" height="800" fill="url(#circuit-grid)" />

          {/* Trilhas e nós */}
          <g
            stroke="currentColor"
            strokeWidth="2"
            strokeOpacity="0.35"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M120 160H320V320H520" />
            <path d="M980 200V420H760V560" />
            <path d="M200 640H420V520H640" />
            <path d="M900 120H1080V300" />
            <path d="M80 440H260V600" />
          </g>
          <g fill="currentColor" fillOpacity="0.5">
            <circle cx="320" cy="320" r="4" />
            <circle cx="520" cy="320" r="4" />
            <circle cx="760" cy="420" r="4" />
            <circle cx="760" cy="560" r="4" />
            <circle cx="420" cy="520" r="4" />
            <circle cx="640" cy="520" r="4" />
            <circle cx="1080" cy="300" r="4" />
            <circle cx="260" cy="600" r="4" />
          </g>
        </motion.g>
      </svg>
    </div>
  );
}
