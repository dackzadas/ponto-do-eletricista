import { MapPin, MessageCircle } from "lucide-react";
import { siteConfig, whatsappLink } from "@/config/site";
import { logoImage } from "@/data/products";
import Reveal from "./Reveal";

// As mesmas âncoras usadas no Header.
const QUICK_LINKS = [
  { label: "Início", href: "#inicio" },
  { label: "Produtos", href: "#produtos" },
  { label: "Ofertas", href: "#ofertas" },
  { label: "Sobre", href: "#sobre" },
  { label: "Contato", href: "#contato" },
];

export default function Footer() {
  return (
    <footer className="relative border-t border-white/10 bg-[#060810]">
      <div className="mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="grid gap-10 md:grid-cols-3">
          {/* Marca */}
          <Reveal>
            <div className="flex items-center gap-3">
              <img
                src={logoImage}
                alt=""
                className="h-10 w-10 object-contain sm:h-12 sm:w-12"
              />
              <p className="font-heading text-base font-extrabold leading-[1.05] tracking-tight text-white">
                <span className="block">PONTO DO</span>
                <span className="block text-[#FFD400] text-glow">ELETRICISTA</span>
              </p>
            </div>
            <p className="mt-4 max-w-xs text-sm text-slate-400">
              Materiais elétricos para instalações, reformas e projetos no
              Coroado, Manaus-AM.
            </p>
          </Reveal>

          {/* Links rápidos */}
          <Reveal delay={0.1}>
            <nav aria-label="Links rápidos">
              <h3 className="font-heading text-sm font-bold uppercase tracking-wider text-white">
                Links rápidos
              </h3>
              <ul className="mt-4 space-y-2.5">
                {QUICK_LINKS.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="inline-block text-sm text-slate-400 transition hover:translate-x-1 hover:text-[#FFD400]"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          </Reveal>

          {/* Contato */}
          <Reveal delay={0.2}>
            <h3 className="font-heading text-sm font-bold uppercase tracking-wider text-white">
              Contato
            </h3>
            <ul className="mt-4 space-y-3">
              <li>
                <a
                  href={whatsappLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-3 text-sm text-slate-400 transition hover:text-[#FFD400]"
                >
                  <MessageCircle className="h-4 w-4 shrink-0 text-[#FFD400]" />
                  {siteConfig.whatsappDisplay}
                </a>
              </li>
              <li className="flex items-start gap-3 text-sm text-slate-400">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-[#FFD400]" />
                {siteConfig.location}
              </li>
            </ul>
          </Reveal>
        </div>

        <Reveal delay={0.3}>
          <div className="mt-12 flex flex-col gap-3 border-t border-white/10 pt-6 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between">
            <p>
              © {new Date().getFullYear()} {siteConfig.name}. Todos os direitos
              reservados.
            </p>
            <p>Imagens ilustrativas. Preços e disponibilidade sujeitos a confirmação.</p>
          </div>
        </Reveal>
      </div>
    </footer>
  );
}
