import * as React from "react";
import { useSize } from "@/hooks/use-size";
import { useResponsiveImage } from "./use-responsive-image";

/**
 * Imagem do Wix Media dimensionada para o container em que é renderizada.
 * O wrapper guarda o aspect-ratio (quando conhecido) para evitar salto de
 * layout; os demais atributos são repassados ao <img>.
 */
export const ResponsiveImage = React.forwardRef(function ResponsiveImage(
  {
    src,
    parsed,
    onSourceChange,
    fittingType = "fill",
    focalPoint,
    quality = 90,
    aspectRatio,
    className,
    style,
    onError,
    ...imgProps
  },
  ref
) {
  const wrapperRef = React.useRef(null);
  const size = useSize(wrapperRef);
  const { imgSrc, srcSet } = useResponsiveImage({
    src,
    parsed,
    size,
    fittingType,
    focalPoint,
    quality,
  });

  return (
    <span
      ref={wrapperRef}
      className="block h-full w-full"
      style={aspectRatio ? { aspectRatio, ...style } : style}
    >
      <img ref={ref} src={imgSrc} srcSet={srcSet} className={className} onError={onError} {...imgProps} />
    </span>
  );
});
