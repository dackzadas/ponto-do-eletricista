import { motion, useReducedMotion } from "framer-motion";

// Envolve o conteúdo com uma animação suave de entrada ao entrar na viewport.
// Uso: <Reveal className="..." delay={0.1}> ... </Reveal>
export default function Reveal({ children, className, delay = 0, as = "div" }) {
  const reduce = useReducedMotion();
  // Com preferência por menos movimento, mantemos apenas o fade de opacidade.
  const initial = reduce ? { opacity: 0 } : { opacity: 0, y: 24 };
  const MotionTag = motion[as] || motion.div;

  return (
    <MotionTag
      className={className}
      initial={initial}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </MotionTag>
  );
}
