import { motion, useReducedMotion } from "framer-motion";
import { MessageCircle, Tag } from "lucide-react";
import { offers, formatBRL } from "@/data/products";
import { whatsappLink } from "@/config/site";
import Reveal from "./Reveal";

export default function Offers() {
  const reduce = useReducedMotion();
  return (
    <section id="ofertas" className="relative py-24 sm:py-32">
      {/* Brilho amarelo de fundo */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_0%,rgba(255,212,0,0.08),transparent_70%)]" />

      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-[#FFD400]/30 bg-[#FFD400]/5 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.2em] text-[#FFD400]">
            <Tag className="h-3.5 w-3.5" />
            Ofertas TOP CABLES
          </span>
          <h2 className="mt-5 font-heading text-3xl font-extrabold leading-tight text-white sm:text-4xl md:text-5xl">
            Ofertas que <span className="text-[#FFD400] text-glow">valem a pena</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Confira os preços especiais para pagamento no dinheiro ou PIX.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {offers.map((p, i) => {
            const discount = Math.round((1 - p.pricePix / p.priceNormal) * 100);
            return (
              <Reveal key={p.name} delay={i * 0.08}>
                <motion.article
                  whileHover={reduce ? undefined : { y: -8 }}
                  transition={{ type: "spring", stiffness: 300, damping: 22 }}
                  className="group relative flex h-full flex-col overflow-hidden rounded-2xl card-glass p-6 transition-colors hover:border-[#FFD400]/40"
                >
                  {/* Selo */}
                  <div className="mb-4 inline-flex w-fit items-center gap-1.5 rounded-full bg-[#FFD400] px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-[#080B12]">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#080B12]" />
                    Preço especial no PIX ou dinheiro
                  </div>

                  <h3 className="font-heading text-base font-bold leading-snug text-white">
                    {p.name}
                  </h3>

                  <div className="mt-5 flex-1">
                    <p className="text-sm text-slate-500 line-through">{formatBRL(p.priceNormal)}</p>
                    <div className="mt-1 flex items-end gap-2">
                      <span className="font-heading text-3xl font-extrabold text-[#FFD400] text-glow">
                        {formatBRL(p.pricePix)}
                      </span>
                      <span className="mb-1 text-xs font-semibold text-slate-400">no PIX/dinheiro</span>
                    </div>
                    {discount > 0 && (
                      <span className="mt-3 inline-flex w-fit rounded-md bg-white/5 px-2 py-0.5 text-[11px] font-semibold text-[#FFD400] ring-1 ring-[#FFD400]/20">
                        -{discount}%
                      </span>
                    )}
                  </div>

                  <a
                    href={whatsappLink(
                      `Olá! Tenho interesse no produto: ${p.name}. Vi o preço especial de ${formatBRL(
                        p.pricePix
                      )} no PIX ou dinheiro. Pode me ajudar?`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-6 flex items-center justify-center gap-2 rounded-full bg-[#FFD400] px-5 py-3 text-sm font-bold text-[#080B12] transition hover:shadow-[0_0_22px_rgba(255,212,0,0.5)] hover:brightness-105"
                  >
                    <MessageCircle className="h-4 w-4" />
                    Consultar no WhatsApp
                  </a>
                </motion.article>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={0.2}>
          <p className="mt-8 text-center text-xs text-slate-500">
            * Preços sujeitos a confirmação. Consulte disponibilidade e condições pelo WhatsApp.
          </p>
        </Reveal>
      </div>
    </section>
  );
}