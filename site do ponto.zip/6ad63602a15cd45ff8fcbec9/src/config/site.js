// Configurações centrais do site — Ponto do Eletricista (Coroado, Manaus-AM).
import { heroImage, storeImage, logoImage } from "@/data/products";

// ATENÇÃO: número real da loja fornecido pelo usuário.
const WHATSAPP_NUMBER = "5592993090656";
const WHATSAPP_DISPLAY = "(92) 99309-0656";

// Monta a URL do WhatsApp; usa uma mensagem padrão quando nenhuma é informada.
export function whatsappLink(message) {
  const text =
    message || "Olá! Gostaria de falar com o Ponto do Eletricista.";
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
}

export const siteConfig = {
  name: "Ponto do Eletricista",
  location: "Coroado — Manaus, Amazonas",
  // Sem dado real de horário de atendimento — deixado vazio de propósito.
  hours: "",
  whatsappDisplay: WHATSAPP_DISPLAY,
  whatsappNumber: WHATSAPP_NUMBER,
  // Redes sociais vazias de propósito: o Contact esconde os botões quando falsy.
  social: { instagram: "", facebook: "" },
};

// Imagens reexportadas de "@/data/products".
export { heroImage, storeImage, logoImage };
