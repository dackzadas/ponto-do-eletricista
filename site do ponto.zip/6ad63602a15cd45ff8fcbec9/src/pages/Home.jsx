import ScrollProgress from "@/components/ScrollProgress";
import LogoBackground from "@/components/LogoBackground";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Products from "@/components/Products";
import Offers from "@/components/Offers";
import Differentials from "@/components/Differentials";
import About from "@/components/About";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";

export default function Home() {
  return (
    <div className="relative min-h-screen bg-[#080B12] text-white">
      <LogoBackground />
      <ScrollProgress />
      <Header />
      <main>
        <Hero />
        <Products />
        <Offers />
        <Differentials />
        <About />
        <Contact />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}