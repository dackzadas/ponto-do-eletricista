import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, MessageCircle, ChevronDown } from "lucide-react";
import { whatsappLink } from "@/config/site";
import CircuitBackground from "./CircuitBackground";

const titleLines = ["ENERGIA PARA", "TIRAR SEUS PROJETOS", "DO PAPEL."];

export default function Hero() {
  const reduce = useReducedMotion();

  return (
    <section id="inicio" className="relative flex min-h-screen items-center overflow-hidden pt-28 pb-16">
      <CircuitBackground />

      <div className="relative mx-auto w-full max-w-7xl px-5 sm:px-8">
        <div className="max-w-2xl">
          <motion.div
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 rounded-full border border-[#FFD400]/30 bg-[#FFD400]/5 px-4 py-1.5 text-xs font-medium text-[#FFD400]"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-[#FFD400] animate-pulse" />
            Coroado · Manaus, Amazonas
          </motion.div>

          {/* Título com revelação linha a linha */}
          <h1 className="mt-6 font-heading text-[2.6rem] font-extrabold leading-[1.05] tracking-tight text-white sm:text-6xl md:text-7xl">
            {titleLines.map((line, i) => (
              <span key={i} className="block overflow-hidden">
                <motion.span
                  initial={reduce ? { opacity: 0 } : { y: "110%" }}
                  animate={reduce ? { opacity: 1 } : { y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 + i * 0.15, ease: [0.22, 1, 0.36, 1] }}
                  className="block"
                  dangerouslySetInnerHTML={{
                    __html: line
                      .replace("ENERGIA", '<span class="text-[#FFD400] text-glow">ENERGIA</span>')
                      .replace("PAPEL.", '<span class="text-[#FFD400] text-glow">PAPEL.</span>'),
                  }}
                />
              </span>
            ))}
          </h1>

          <motion.p
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.8 }}
            className="mt-6 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg"
          >
            Materiais elétricos para suas instalações, reformas e projetos. Conte com o Ponto do
            Eletricista, no Coroado, em Manaus.
          </motion.p>

          <motion.div
            initial={reduce ? { opacity: 0 } : { opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 1 }}
            className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center"
          >
            <button
              onClick={() =>
                document.querySelector("#produtos")?.scrollIntoView({ behavior: reduce ? "auto" : "smooth" })
              }
              className="group flex items-center justify-center gap-2 rounded-full bg-[#FFD400] px-7 py-3.5 text-sm font-bold text-[#080B12] transition hover:shadow-[0_0_28px_rgba(255,212,0,0.55)] hover:brightness-105"
            >
              VER PRODUTOS
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
            </button>
            <a
              href={whatsappLink("Olá! Gostaria de pedir um orçamento no Ponto do Eletricista.")}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-center gap-2 rounded-full border border-white/15 bg-white/5 px-7 py-3.5 text-sm font-bold text-white backdrop-blur-sm transition hover:border-[#FFD400]/50 hover:text-[#FFD400]"
            >
              <MessageCircle className="h-4 w-4" />
              PEDIR ORÇAMENTO NO WHATSAPP
            </a>
          </motion.div>
        </div>
      </div>

      {/* Indicador de rolagem */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.6 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 text-slate-400"
      >
        <motion.div
          animate={reduce ? undefined : { y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex flex-col items-center gap-1"
        >
          <span className="text-[10px] uppercase tracking-[0.3em]">Role</span>
          <ChevronDown className="h-5 w-5 text-[#FFD400]" />
        </motion.div>
      </motion.div>
    </section>
  );
}