import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { MessageCircle, Send, MapPin, Clock, Instagram, Facebook } from "lucide-react";
import { siteConfig, whatsappLink } from "@/config/site";
import Reveal from "./Reveal";

export default function Contact() {
  const reduce = useReducedMotion();
  const [form, setForm] = useState({ nome: "", produto: "", mensagem: "" });
  const [errors, setErrors] = useState({});
  const [sending, setSending] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.nome.trim()) e.nome = "Informe seu nome.";
    if (!form.mensagem.trim()) e.mensagem = "Escreva sua mensagem.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setSending(true);
    const text =
      `Olá, Ponto do Eletricista!\n\n` +
      `*Nome:* ${form.nome}\n` +
      (form.produto ? `*Produto de interesse:* ${form.produto}\n` : "") +
      `*Mensagem:* ${form.mensagem}`;
    // Abre o WhatsApp com a mensagem — só afirmamos envio se a conversa for aberta.
    window.open(whatsappLink(text), "_blank");
    setTimeout(() => {
      setSending(false);
      setForm({ nome: "", produto: "", mensagem: "" });
    }, 600);
  };

  const field = (name) => (value) =>
    setForm((f) => ({ ...f, [name]: value }));

  return (
    <section id="contato" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-[#FFD400]">
            Contato
          </span>
          <h2 className="mt-4 font-heading text-3xl font-extrabold leading-tight text-white sm:text-4xl md:text-5xl">
            Vamos tirar seu <span className="text-[#FFD400] text-glow">projeto do papel</span>?
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Fale com nossa equipe e consulte os produtos e preços disponíveis.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-8 lg:grid-cols-2">
          {/* Coluna de info */}
          <Reveal className="flex flex-col gap-5">
            <a
              href={whatsappLink()}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-4 rounded-2xl card-glass p-5 transition hover:border-[#FFD400]/30"
            >
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#FFD400] text-[#080B12]">
                <MessageCircle className="h-6 w-6" />
              </span>
              <div>
                <p className="text-sm text-slate-400">WhatsApp</p>
                <p className="font-heading font-bold text-white group-hover:text-[#FFD400] transition">
                  {siteConfig.whatsappDisplay}
                </p>
              </div>
            </a>

            <div className="flex items-center gap-4 rounded-2xl card-glass p-5">
              <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white/5 text-[#FFD400] ring-1 ring-white/10">
                <MapPin className="h-6 w-6" />
              </span>
              <div>
                <p className="text-sm text-slate-400">Localização</p>
                <p className="font-heading font-bold text-white">{siteConfig.location}</p>
              </div>
            </div>

            {siteConfig.hours && (
              <div className="flex items-center gap-4 rounded-2xl card-glass p-5">
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-white/5 text-[#FFD400] ring-1 ring-white/10">
                  <Clock className="h-6 w-6" />
                </span>
                <div>
                  <p className="text-sm text-slate-400">Horário de atendimento</p>
                  <p className="font-heading font-bold text-white">{siteConfig.hours}</p>
                </div>
              </div>
            )}

            {(siteConfig.social.instagram || siteConfig.social.facebook) && (
              <div className="flex items-center gap-3">
                {siteConfig.social.instagram && (
                  <a href={siteConfig.social.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram"
                     className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 text-white/80 transition hover:border-[#FFD400]/50 hover:text-[#FFD400]">
                    <Instagram className="h-5 w-5" />
                  </a>
                )}
                {siteConfig.social.facebook && (
                  <a href={siteConfig.social.facebook} target="_blank" rel="noopener noreferrer" aria-label="Facebook"
                     className="grid h-11 w-11 place-items-center rounded-xl border border-white/10 text-white/80 transition hover:border-[#FFD400]/50 hover:text-[#FFD400]">
                    <Facebook className="h-5 w-5" />
                  </a>
                )}
              </div>
            )}
          </Reveal>

          {/* Formulário */}
          <Reveal delay={0.1}>
            <form onSubmit={submit} className="card-glass rounded-2xl p-6 sm:p-8">
              <div className="space-y-5">
                <div>
                  <label htmlFor="nome" className="mb-1.5 block text-sm font-medium text-slate-300">
                    Seu nome
                  </label>
                  <input
                    id="nome"
                    type="text"
                    value={form.nome}
                    onChange={(e) => field("nome")(e.target.value)}
                    placeholder="Como podemos te chamar?"
                    className={`w-full rounded-xl border bg-[#0B1018] px-4 py-3 text-white placeholder:text-slate-500 outline-none transition focus:border-[#FFD400] focus:ring-1 focus:ring-[#FFD400] ${
                      errors.nome ? "border-red-500/60" : "border-white/10"
                    }`}
                  />
                  {errors.nome && <p className="mt-1 text-xs text-red-400">{errors.nome}</p>}
                </div>

                <div>
                  <label htmlFor="produto" className="mb-1.5 block text-sm font-medium text-slate-300">
                    Produto desejado <span className="text-slate-500">(opcional)</span>
                  </label>
                  <input
                    id="produto"
                    type="text"
                    value={form.produto}
                    onChange={(e) => field("produto")(e.target.value)}
                    placeholder="Ex: Cabo 2,5 mm² TOP CABLES"
                    className="w-full rounded-xl border border-white/10 bg-[#0B1018] px-4 py-3 text-white placeholder:text-slate-500 outline-none transition focus:border-[#FFD400] focus:ring-1 focus:ring-[#FFD400]"
                  />
                </div>

                <div>
                  <label htmlFor="mensagem" className="mb-1.5 block text-sm font-medium text-slate-300">
                    Mensagem
                  </label>
                  <textarea
                    id="mensagem"
                    rows={4}
                    value={form.mensagem}
                    onChange={(e) => field("mensagem")(e.target.value)}
                    placeholder="Descreva o que você procura..."
                    className={`w-full resize-none rounded-xl border bg-[#0B1018] px-4 py-3 text-white placeholder:text-slate-500 outline-none transition focus:border-[#FFD400] focus:ring-1 focus:ring-[#FFD400] ${
                      errors.mensagem ? "border-red-500/60" : "border-white/10"
                    }`}
                  />
                  {errors.mensagem && <p className="mt-1 text-xs text-red-400">{errors.mensagem}</p>}
                </div>

                <motion.button
                  type="submit"
                  disabled={sending}
                  whileTap={reduce ? undefined : { scale: 0.97 }}
                  className="flex w-full items-center justify-center gap-2 rounded-full bg-[#FFD400] px-6 py-3.5 font-semibold text-[#080B12] transition hover:shadow-[0_0_24px_rgba(255,212,0,0.5)] hover:brightness-105 disabled:opacity-70"
                >
                  <Send className="h-5 w-5" />
                  {sending ? "Abrindo WhatsApp..." : "Enviar solicitação"}
                </motion.button>
                <p className="text-center text-xs text-slate-500">
                  Ao enviar, abriremos o WhatsApp com sua mensagem pronta.
                </p>
              </div>
            </form>
          </Reveal>
        </div>
      </div>
    </section>
  );
}