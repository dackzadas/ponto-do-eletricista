import { motion, useReducedMotion } from "framer-motion";
import { logoImage } from "@/data/products";

// Marca d'água fixa da logo, em opacidade mínima, com um brilho amarelo sutil.
export default function LogoBackground() {
  const reduce = useReducedMotion();
  return (
    <div
      className="pointer-events-none fixed inset-0 -z-10 overflow-hidden"
      aria-hidden="true"
    >
      {/* Gradiente radial amarelo de apoio */}
      <div className="absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_40%,rgba(255,212,0,0.06),transparent_70%)]" />
      {/* O posicionamento fica no wrapper para não conflitar com a flutuação */}
      <div className="absolute left-1/2 top-1/2 h-[70vmin] w-[70vmin] -translate-x-1/2 -translate-y-1/2">
        <motion.img
          src={logoImage}
          alt=""
          animate={reduce ? undefined : { y: [0, -14, 0] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="h-full w-full object-contain opacity-[0.04]"
        />
      </div>
    </div>
  );
}
