// Helpers de URL do componente <Image> (imagens do Wix Media Platform).
// São funções puras, sem dependência de React.

export const IMAGE_LOAD_MODE = {
  OPTIMIZED: "optimized",
  ORIGINAL: "original",
  FALLBACK: "fallback",
};

export const IMAGE_FORMAT = {
  AVIF: "avif",
  WEBP: "webp",
};

// Sequência de tentativas: transformação otimizada → URL original → fallback genérico.
export function nextImageLoadMode(mode) {
  return mode === IMAGE_LOAD_MODE.OPTIMIZED ? IMAGE_LOAD_MODE.ORIGINAL : IMAGE_LOAD_MODE.FALLBACK;
}

const WIX_MEDIA_HOST = "static.wixstatic.com";
const WIX_MEDIA_PATH = "/media/";
const TRANSFORM_SEGMENT = "/v1/";

/**
 * Reconhece uma URL de imagem do Wix Media e devolve seus dados canônicos
 * (sem o segmento de transformação). Devolve null para qualquer outra URL —
 * nesse caso o componente renderiza um <img> comum.
 */
export function parseWixMediaUrl(url) {
  if (typeof url !== "string" || !url) return null;

  let parsedUrl;
  try {
    parsedUrl = new URL(url);
  } catch {
    return null;
  }

  if (parsedUrl.hostname !== WIX_MEDIA_HOST) return null;

  const pathname = parsedUrl.pathname.split(TRANSFORM_SEGMENT)[0];
  if (!pathname.startsWith(WIX_MEDIA_PATH)) return null;

  const fileName = pathname.slice(WIX_MEDIA_PATH.length);
  if (!fileName) return null;

  return {
    fileName,
    baseUrl: `${parsedUrl.origin}${pathname}`,
    search: parsedUrl.search ?? "",
  };
}

// URL sem transformação — usada quando a versão otimizada falha.
export function getOriginalImageUrl(src, parsed) {
  return parsed ? `${parsed.baseUrl}${parsed.search}` : src;
}

/** Monta a URL de transformação do Wix Media para o tamanho/qualidade pedidos. */
export function buildTransformUrl(
  parsed,
  { width, height, fittingType = "fill", focalPoint, quality = 90, format } = {}
) {
  if (!parsed || !width) return null;

  const params = [`w_${Math.round(width)}`];
  if (height) params.push(`h_${Math.round(height)}`);
  params.push("al_c");
  if (focalPoint) params.push(`fp_${focalPoint.x}_${focalPoint.y}`);
  params.push(`q_${Math.round(quality)}`);
  if (format) params.push(`enc_${format}`);

  return `${parsed.baseUrl}${TRANSFORM_SEGMENT}${fittingType}/${params.join(",")}/${parsed.fileName}${parsed.search}`;
}

let formatSupport;

/** Detecta (uma vez por sessão) o suporte do navegador a um formato de imagem. */
export function supportsImageFormat(format) {
  if (typeof document === "undefined") return false;
  if (!formatSupport) formatSupport = {};
  if (format in formatSupport) return formatSupport[format];

  const canvas = document.createElement("canvas");
  canvas.width = 1;
  canvas.height = 1;
  formatSupport[format] = canvas.toDataURL(`image/${format}`).startsWith(`data:image/${format}`);
  return formatSupport[format];
}

// Densidade de pixels, limitada para não gerar imagens grandes demais.
export function getDevicePixelRatio(maxRatio = 2) {
  if (typeof window === "undefined") return 1;
  return Math.min(window.devicePixelRatio || 1, maxRatio);
}
