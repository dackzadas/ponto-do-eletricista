import { useMemo } from "react";
import {
  IMAGE_FORMAT,
  buildTransformUrl,
  getDevicePixelRatio,
  getOriginalImageUrl,
  supportsImageFormat,
} from "./image-helpers";

// Larguras (em px CSS) geradas para o atributo srcSet.
const SRCSET_WIDTHS = [320, 640, 960, 1280];

const preferredFormat = () => {
  if (supportsImageFormat(IMAGE_FORMAT.AVIF)) return IMAGE_FORMAT.AVIF;
  if (supportsImageFormat(IMAGE_FORMAT.WEBP)) return IMAGE_FORMAT.WEBP;
  return undefined;
};

/**
 * Calcula a URL otimizada (e o srcSet) de uma imagem do Wix Media a partir do
 * tamanho real do container. Enquanto o container não foi medido, devolve a URL
 * original para não disparar uma requisição com o tamanho errado.
 */
export function useResponsiveImage({
  src,
  parsed,
  size,
  fittingType = "fill",
  focalPoint,
  quality = 90,
}) {
  return useMemo(() => {
    const originalSrc = getOriginalImageUrl(src, parsed);
    if (!parsed || !size?.width) return { imgSrc: originalSrc, srcSet: undefined };

    const dpr = getDevicePixelRatio();
    const ratio = size.height ? size.height / size.width : undefined;
    const format = preferredFormat();

    const transform = (width) =>
      buildTransformUrl(parsed, {
        width,
        height: ratio ? Math.round(width * ratio) : undefined,
        fittingType,
        focalPoint,
        quality,
        format,
      });

    return {
      imgSrc: transform(Math.round(size.width * dpr)),
      srcSet: SRCSET_WIDTHS.map((width) => `${transform(width)} ${width}w`).join(", "),
    };
  }, [src, parsed, size, fittingType, focalPoint, quality]);
}
