// Utilitários compartilhados pelas páginas de autenticação.

// Validação simples de e-mail (não tenta cobrir toda a RFC).
export function isValidEmail(value: string): boolean {
  if (typeof value !== "string") return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

// Remove tudo que não for dígito (ex.: telefone/WhatsApp).
export function onlyDigits(value: string): string {
  if (typeof value !== "string") return "";
  return value.replace(/\D/g, "");
}
