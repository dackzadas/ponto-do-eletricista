// Indicador animado de progresso da rolagem da página.
import { motion, useScroll, useSpring } from "framer-motion";

export default function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 30, mass: 0.3 });
  return (
    <motion.div
      className="fixed left-0 top-0 z-[60] h-[3px] w-full origin-left bg-gradient-to-r from-[#FFD400] via-[#FFD400] to-[#FFB300] shadow-[0_0_12px_rgba(255,212,0,0.6)]"
      style={{ scaleX }}
      aria-hidden="true"
    />
  );
}