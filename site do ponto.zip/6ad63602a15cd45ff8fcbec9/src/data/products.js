const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

// Dados dos produtos — separados da apresentação visual.
// Imagens ilustrativas (não são fotografias do estabelecimento).

const IMG = {
  cabos:
    "https://i.ibb.co/YxyNZDf/cabdb5f0-a952-498a-b73f-601ccd2c516b.jpg",
  disjuntores:
    "https://i.ibb.co/DHQKYGWn/af77e39e-2a79-4271-92df-aa6f01955c0a.jpg",
  tomadas:
    "https://i.ibb.co/cXhqbGRz/tomadas.jpg",
  iluminacao:
    "https://i.ibb.co/PZwP1R00/246906bf-6756-4717-bb72-7f4e756c4eb9-1.jpg",
  ferramentas:
    "https://i.ibb.co/rRpBY1mZ/59f9e2ee-cc85-48d9-9e3e-6d504c768c5d.jpg",
  instalacao:
    "https://i.ibb.co/FbyGP13V/Whats-App-Image-2026-10-19-at-16-55-04.jpg",
};

export const categories = [
  {
    id: "cabos",
    name: "Cabos e fios elétricos",
    description: "Condutores de cobre para diferentes tipos de instalação.",
    image: IMG.cabos,
    query: "Gostaria de consultar cabos e fios elétricos disponíveis.",
  },
  {
    id: "disjuntores",
    name: "Disjuntores e proteção",
    description: "Proteção elétrica para sua instalação com segurança.",
    image: IMG.disjuntores,
    query: "Gostaria de consultar disjuntores e materiais de proteção.",
  },
  {
    id: "tomadas",
    name: "Tomadas e interruptores",
    description: "Acabamentos modernos para suas instalações elétricas.",
    image: IMG.tomadas,
    query: "Gostaria de consultar tomadas e interruptores disponíveis.",
  },
  {
    id: "iluminacao",
    name: "Iluminação",
    description: "Luminárias e lâmpadas para iluminar seus ambientes.",
    image: IMG.iluminacao,
    query: "Gostaria de consultar opções de iluminação.",
  },
  {
    id: "ferramentas",
    name: "Ferramentas",
    description: "Ferramentas profissionais para o seu trabalho com elétrica.",
    image: IMG.ferramentas,
    query: "Gostaria de consultar ferramentas disponíveis.",
  },
  {
    id: "instalacao",
    name: "Materiais para instalação",
    description: "Eletrocalhas, conduítes, caixas e acessórios para sua obra.",
    image: IMG.instalacao,
    query: "Gostaria de consultar materiais para instalação elétrica.",
  },
];

// Ofertas TOP CABLES — valores exatos confirmados.
export const offers = [
  {
    name: "Cabo 2,5 mm² TOP CABLES",
    priceNormal: 340.0,
    pricePix: 289.0,
  },
  {
    name: "Cabo 4,0 mm² TOP CABLES",
    priceNormal: 502.0,
    pricePix: 426.0,
  },
  {
    name: "Cabo 6,0 mm² TOP CABLES",
    priceNormal: 751.0,
    pricePix: 638.0,
  },
  {
    name: "Cabo 10,0 mm² 750V TOP CABLES",
    priceNormal: 1286.0,
    pricePix: 1093.0,
  },
];

export const heroImage =
  "https://media.db.com/images/public/6ad63602a15cd45ff8fcbec9/b33a3dfbb_generated_627135e9.png";
// Fotografia real da fachada da loja no Coroado.
export const storeImage =
  "https://i.ibb.co/5hvtNW9B/08afaa686-image.png";
// Logo do mascote da marca.
export const logoImage =
  "https://i.ibb.co/GQCJgZyc/mascot-Buov-Fe-Zz.png";

// Formata valor em R$.
export const formatBRL = (value) =>
  value.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
    minimumFractionDigits: 2,
  });