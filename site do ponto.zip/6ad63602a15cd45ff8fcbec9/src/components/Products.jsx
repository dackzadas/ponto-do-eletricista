import { motion, useReducedMotion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { categories } from "@/data/products";
import { whatsappLink } from "@/config/site";
import { Image } from "@/components/ui/image";
import Reveal from "./Reveal";

export default function Products() {
  const reduce = useReducedMotion();

  return (
    <section id="produtos" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-[#FFD400]">
            Produtos
          </span>
          <h2 className="mt-4 font-heading text-3xl font-extrabold leading-tight text-white sm:text-4xl md:text-5xl">
            Tudo para a sua{" "}
            <span className="text-[#FFD400] text-glow">instalação elétrica</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Confira as principais categorias disponíveis na loja. Consulte
            modelos e preços pelo WhatsApp.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c, i) => (
            <Reveal key={c.id} delay={i * 0.08}>
              <motion.article
                whileHover={reduce ? undefined : { y: -8 }}
                transition={{ type: "spring", stiffness: 300, damping: 22 }}
                className="group flex h-full flex-col overflow-hidden rounded-2xl card-glass transition-colors hover:border-[#FFD400]/40"
              >
                <div className="relative h-52 overflow-hidden">
                  <Image
                    src={c.image}
                    alt={c.name}
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#080B12] via-[#080B12]/30 to-transparent" />
                </div>

                <div className="flex flex-1 flex-col p-6">
                  <h3 className="font-heading text-lg font-bold text-white">
                    {c.name}
                  </h3>
                  <p className="mt-2 flex-1 text-sm text-slate-400">
                    {c.description}
                  </p>
                  <a
                    href={whatsappLink(c.query)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-5 inline-flex items-center justify-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-bold text-white transition hover:border-[#FFD400]/50 hover:text-[#FFD400]"
                  >
                    <MessageCircle className="h-4 w-4" />
                    Consultar
                  </a>
                </div>
              </motion.article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
