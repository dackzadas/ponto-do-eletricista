import { motion, useReducedMotion } from "framer-motion";
import { Truck, Tags, Headset, ShieldCheck } from "lucide-react";
import Reveal from "./Reveal";

// Diferenciais da loja — ícones coerentes com o comércio de materiais elétricos.
const ITEMS = [
  {
    icon: Truck,
    title: "Entrega rápida",
    text: "Agilidade para levar o material até a sua obra ou reforma na região.",
  },
  {
    icon: Tags,
    title: "Preço especial para eletricistas",
    text: "Condições pensadas para quem compra em quantidade e trabalha no ramo.",
  },
  {
    icon: Headset,
    title: "Atendimento especializado",
    text: "Equipe pronta para ajudar a escolher o material certo para cada projeto.",
  },
  {
    icon: ShieldCheck,
    title: "Marcas de confiança",
    text: "Produtos de marcas reconhecidas para instalações seguras e duráveis.",
  },
];

export default function Differentials() {
  const reduce = useReducedMotion();

  return (
    <section id="diferenciais" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.25em] text-[#FFD400]">
            Diferenciais
          </span>
          <h2 className="mt-4 font-heading text-3xl font-extrabold leading-tight text-white sm:text-4xl md:text-5xl">
            Por que comprar no{" "}
            <span className="text-[#FFD400] text-glow">Ponto do Eletricista</span>
          </h2>
          <p className="mt-4 text-base text-slate-400">
            Tudo o que você precisa para tirar seu projeto do papel, com apoio de
            quem entende de elétrica.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {ITEMS.map((item, i) => {
            const Icon = item.icon;
            return (
              <Reveal key={item.title} delay={i * 0.08}>
                <motion.div
                  whileHover={reduce ? undefined : { y: -6 }}
                  transition={{ type: "spring", stiffness: 300, damping: 22 }}
                  className="group flex h-full flex-col rounded-2xl card-glass p-6 transition-colors hover:border-[#FFD400]/40"
                >
                  <span className="grid h-12 w-12 place-items-center rounded-xl bg-[#FFD400] text-[#080B12] transition-transform duration-300 group-hover:scale-110 group-hover:-rotate-3">
                    <Icon className="h-6 w-6" />
                  </span>
                  <h3 className="mt-5 font-heading text-lg font-bold text-white">
                    {item.title}
                  </h3>
                  <p className="mt-2 text-sm text-slate-400">{item.text}</p>
                </motion.div>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
