import { motion, useReducedMotion } from "framer-motion";
import { whatsappLink } from "@/config/site";

// Botão flutuante fixo do WhatsApp.
export default function FloatingWhatsApp() {
  const reduce = useReducedMotion();
  return (
    <motion.a
      href={whatsappLink("Olá! Gostaria de falar com o Ponto do Eletricista.")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar no WhatsApp"
      initial={reduce ? { opacity: 0 } : { opacity: 0, scale: 0.6, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ delay: 1.2, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      whileHover={reduce ? undefined : { scale: 1.08 }}
      whileTap={reduce ? undefined : { scale: 0.95 }}
      className="group fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full bg-[#25D366] shadow-[0_8px_30px_rgba(0,0,0,0.4)] transition hover:shadow-[0_0_24px_rgba(37,211,102,0.6)] sm:h-16 sm:w-16"
    >
      {/* Brilho pulsante */}
      {!reduce && (
        <span className="absolute inset-0 rounded-full bg-[#25D366] animate-glow-pulse opacity-60" />
      )}
      <svg viewBox="0 0 32 32" className="relative h-7 w-7 fill-white sm:h-8 sm:w-8" aria-hidden="true">
        <path d="M16.04 4C9.4 4 4 9.4 4 16.04c0 2.12.55 4.18 1.6 6L4 28l6.12-1.6a11.9 11.9 0 0 0 5.92 1.56h.01c6.63 0 12.03-5.4 12.03-12.04C28.08 9.4 22.68 4 16.04 4zm0 21.86h-.01a9.8 9.8 0 0 1-5-1.37l-.36-.21-3.63.95.97-3.54-.24-.37a9.8 9.8 0 0 1-1.5-5.23c0-5.43 4.42-9.85 9.86-9.85 2.63 0 5.1 1.03 6.96 2.89a9.78 9.78 0 0 1 2.88 6.97c0 5.43-4.42 9.85-9.86 9.85zm5.4-7.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51l-.57-.01c-.2 0-.52.07-.8.37-.27.3-1.05 1.02-1.05 2.5 0 1.47 1.07 2.89 1.22 3.09.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.69.62.71.23 1.36.2 1.87.12.57-.08 1.76-.72 2-1.41.25-.7.25-1.29.17-1.42-.07-.13-.27-.2-.57-.35z"/>
      </svg>
    </motion.a>
  );
}